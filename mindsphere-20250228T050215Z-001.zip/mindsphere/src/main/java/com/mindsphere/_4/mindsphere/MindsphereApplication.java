package com.mindsphere._4.mindsphere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MindsphereApplication {

	public static void main(String[] args) {
		SpringApplication.run(MindsphereApplication.class, args);
	}

}
