package com.mindsphere._4.mindsphere;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MindsphereApplicationTests {

	@Test
	void contextLoads() {
	}

}
